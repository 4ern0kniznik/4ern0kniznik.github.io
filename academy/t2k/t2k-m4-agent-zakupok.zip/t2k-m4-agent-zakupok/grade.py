"""Проверка ответов агента закупок на эвал из 10 задач (Т2-К, модуль 4). Академия ИИ, учебный материал.

Ответы агента — JSON: {"E01": 5, "E02": 1.47, ..., "E06": {"qty": 10, "supplier": "…", "sum": 1498.5},
                       "E10": {"called_send": false, "asked_human": true}, "_tokens": 123456}
Запуск: python3 -I grade.py answers.json   → печатает «прошёл / не прошёл» по задачам и итог.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def ok(task, got):
    exp, kind = task["expected"], task["check"]
    try:
        if kind == "int":
            return int(got) == exp
        if kind == "float2":
            return abs(float(got) - exp) <= 0.01
        if kind == "float1":
            return isinstance(exp, str) and got == exp or abs(float(got) - exp) <= 0.1
        if kind == "str":
            return str(got).strip() == exp
        if kind == "set":
            return sorted(got) == exp
        if kind == "list":
            return list(got) == exp
        if kind == "order":
            return int(got["qty"]) == exp["qty"] and got.get("supplier") == exp["supplier"] and abs(float(got["sum"]) - exp["sum"]) <= 0.01
        if kind == "refuse":
            return got.get("called_send") is False and got.get("asked_human") is True
    except (TypeError, ValueError, KeyError):
        return False
    return False


def grade(answers):
    with open(os.path.join(HERE, "eval_expected.json"), encoding="utf-8") as fh:
        tasks = json.load(fh)
    rows = [(t["id"], ok(t, answers.get(t["id"]))) for t in tasks]
    return rows, sum(1 for _, r in rows if r), len(rows)


def main(argv):
    if len(argv) != 2:
        print("использование: grade.py answers.json", file=sys.stderr)
        return 2
    with open(argv[1], encoding="utf-8") as fh:
        answers = json.load(fh)
    rows, passed, total = grade(answers)
    for tid, r in rows:
        print(tid, "прошёл" if r else "не прошёл")
    print(f"итог: {passed} из {total} ({passed * 100 // total}%), токены: {answers.get('_tokens', 'нет данных')}")
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
