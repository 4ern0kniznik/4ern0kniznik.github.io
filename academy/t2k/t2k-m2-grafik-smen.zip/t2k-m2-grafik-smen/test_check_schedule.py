"""Тесты проверки графика (Т2-К, модуль 2). Запуск: python3 -I test_check_schedule.py -v (из этой папки)."""
import copy
import json
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from check_schedule import check_schedule  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(HERE, "schedule_ok.json"), encoding="utf-8") as f:
    BASE = json.load(f)


def rules(data):
    return sorted({v.rule for v in check_schedule(data)})


def add(data, who, start, end):
    data["shifts"].append({"id": who, "start": start, "end": end})


class TestSchedule(unittest.TestCase):
    def setUp(self):
        self.d = copy.deepcopy(BASE)

    def test_base_is_clean(self):
        self.assertEqual(check_schedule(self.d), [])

    def test_h1_over_40(self):
        # С-01: пять смен по 7 ч = 35 ч; плюс суббота 09–16 = 42 ч
        add(self.d, "С-01", "2026-11-14T09:00", "2026-11-14T16:00")
        self.assertIn("H1", rules(self.d))

    def test_h1_exactly_40_ok(self):
        add(self.d, "С-01", "2026-11-14T09:00", "2026-11-14T14:00")  # 35 + 5 = 40
        self.assertNotIn("H1", rules(self.d))

    def test_h2_minor_over_35(self):
        # С-06 (17 лет): 4 смены = 28 ч; плюс среда и четверг = 42 ч
        add(self.d, "С-06", "2026-11-11T09:00", "2026-11-11T16:00")
        add(self.d, "С-06", "2026-11-12T09:00", "2026-11-12T16:00")
        self.assertIn("H2", rules(self.d))

    def test_h3_minor_at_night(self):
        add(self.d, "С-06", "2026-11-12T17:00", "2026-11-12T22:30")
        self.assertIn("H3", rules(self.d))

    def test_h3_minor_until_22_ok(self):
        add(self.d, "С-06", "2026-11-12T17:00", "2026-11-12T22:00")
        self.assertNotIn("H3", rules(self.d))

    def test_h3_adult_night_ok(self):
        add(self.d, "С-05", "2026-11-12T22:00", "2026-11-13T02:00")
        self.assertNotIn("H3", rules(self.d))

    def test_h4_no_42h_rest(self):
        # С-06 работает среду–пятницу по 2 ч (всю неделю без выходных): самый длинный отдых меньше 42 ч
        for day in ("11", "12", "13"):
            add(self.d, "С-06", f"2026-11-{day}T10:00", f"2026-11-{day}T12:00")
        self.assertIn("H4", rules(self.d))

    def test_m1_evening_then_morning(self):
        # С-03: вечер пятницы до 22:00, утро субботы с 09:00 — 11 ч
        add(self.d, "С-03", "2026-11-14T09:00", "2026-11-14T10:00")
        self.assertIn("M1", rules(self.d))

    def test_m2_coverage_gap(self):
        self.d["shifts"] = [s for s in self.d["shifts"] if not (s["id"] == "С-01" and s["start"].startswith("2026-11-10"))]
        v = [x for x in check_schedule(self.d) if x.rule == "M2"]
        self.assertEqual(len(v), 6)  # вторник 09–15: один человек; с 15:00 выходит вечерняя смена

    def test_unknown_employee(self):
        add(self.d, "С-99", "2026-11-12T09:00", "2026-11-12T10:00")
        self.assertIn("DATA", rules(self.d))

    def test_overlap(self):
        add(self.d, "С-01", "2026-11-09T15:00", "2026-11-09T17:00")
        self.assertIn("DATA", rules(self.d))


if __name__ == "__main__":
    unittest.main()
